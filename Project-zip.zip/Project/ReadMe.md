## 1. Business Use Case

Customer churn is one of the most pressing challenges within the telecommunications industry, where competition is intense and customer acquisition costs are high. Retaining existing customers is significantly more cost-effective than acquiring new ones, and small improvements in churn rates can lead to substantial gains in Customer Lifetime Value (CLV) and long-term revenue.

The objective of this project is to build a predictive model capable of identifying customers who are at high risk of leaving the company. By learning behavioral patterns from historical customer data, the model can provide early warnings that a customer may churn. This enables the business to intervene proactively through targeted retention actions such as personalized offers, contract adjustments, or enhanced support.

The ultimate goal is to support the design of **focused customer retention programs** that allow the company to:

- Reduce churn rates  
- Increase CLV  
- Optimize marketing and retention expenditures  
- Strengthen customer relationships  
- Improve business stability and recurring revenue  

In essence, the model transforms raw customer data into actionable insights that guide strategic retention decisions and maximize value generation.

---

## 2. Dataset Description

This project uses the **Telco Customer Churn** dataset, publicly available on Kaggle and originally sourced from IBM Sample Data Sets. It is widely used for churn prediction research and provides a realistic representation of customer behavior in the telecom sector.

The raw dataset contains:

- **7,043 rows** — each representing an individual customer  
- **21 columns** — a mix of demographic, service-usage, and account-level attributes  
- **1 binary target variable**: `Churn` (Yes/No)

### **Dataset Structure**

#### **1. Customer Demographics**
Describe basic characteristics of each customer:
- `gender`  
- `SeniorCitizen`  
- `Partner`  
- `Dependents`  

These features help analyze how personal attributes correlate with churn behavior.

#### **2. Services Subscribed**
Indicate the services customers have signed up for:
- `PhoneService`, `MultipleLines`  
- `InternetService` (DSL, Fiber optic, No)  
- `OnlineSecurity`, `OnlineBackup`  
- `DeviceProtection`, `TechSupport`  
- `StreamingTV`, `StreamingMovies`  

These variables provide insight into the customer’s level of engagement with company services.

#### **3. Account and Contract Information**
Capture the financial and contractual details of each customer:
- `tenure`  
- `Contract` (Month-to-month, One year, Two year)  
- `PaperlessBilling`  
- `PaymentMethod`  
- `MonthlyCharges`, `TotalCharges`  

These are often highly predictive of churn due to their direct link to customer loyalty and billing behavior.

#### **4. Target Variable**
- `Churn` — indicates whether the customer left the company within the last month.

---

### **Dataset Origin and Purpose**

The dataset’s official description states:

> “Predict behavior to retain customers. You can analyze all relevant customer data and develop focused customer retention programs.”

This aligns directly with the business use case of the project—using historical customer data to anticipate churn, understand underlying drivers, and design strategies that improve retention and protect revenue.

## 3. Baseline Model

### Features Used
The baseline model utilized a comprehensive set of features spanning demographics, customer services, and account information:

- **Numerical features:** `tenure`, `MonthlyCharges`, `TotalCharges`  
- **Categorical features:** `SeniorCitizen`, `gender`, `Partner`, `Dependents`, `PhoneService`, `MultipleLines`, `InternetService`, `OnlineSecurity`, `OnlineBackup`, `DeviceProtection`, `TechSupport`, `StreamingTV`, `StreamingMovies`, `Contract`, `PaperlessBilling`, `PaymentMethod`

### Pre-Processing
- Numerical features were standardized using **StandardScaler** to ensure uniform scale.  
- Categorical features were transformed via **OneHotEncoder** with `handle_unknown='ignore'` to accommodate unseen categories during inference.  
- The target variable `Churn` was binarized (`Yes` → 1, `No` → 0).

### Validation Strategy
- Data was split into **70% training** and **30% test** sets, stratified by the target variable to preserve class distribution.  
- Within training, **Stratified 5-Fold Cross-Validation** was employed during hyperparameter tuning to ensure robust performance estimates across imbalanced classes.

### Model
- A **Logistic Regression** classifier was selected as the baseline model for its interpretability and efficiency.  
- Hyperparameter tuning was performed over the regularization parameter `C` using **GridSearchCV**.

### Metrics Obtained

| Metric              | Score   |
|---------------------|---------|
| Accuracy            | 80.8%   |
| Precision (Churn=1) | 67%     |
| Recall (Churn=1)    | 56%     |
| F1-Score (Churn=1)  | 61%     |

Additional observations:

- The model achieves solid accuracy (80.8%) reflecting good general classification performance.  
- Precision and recall for the churn class are moderate, with recall at 56%, indicating room for improvement in capturing churners.  
- These results set a meaningful baseline to enhance with further feature engineering and model tuning.

---

## 4. Iterative Model Improvements

### Iteration 1: Logistic Regression (Bayesian Optimization)
- **Change:** Replaced GridSearchCV with Bayesian optimization to tune `C` efficiently.  
- **Impact:** Slight improvement in F1 for churners.  
| Metric             | Score   |
|--------------------|---------|
| Accuracy           | 80.8%   |
| Precision (Churn=1)| 67%     |
| Recall (Churn=1)   | 56%     |
| F1-Score (Churn=1) | 61%     |

### Iteration 2: Random Forest (Bayesian Optimization)
- **Change:** Switched to Random Forest; tuned `n_estimators`, `max_depth`, `min_samples_split`, `min_samples_leaf`, `max_features`, `class_weight`.  
- **Impact:** Recall for churners improved significantly to 78%, detecting more at-risk customers. Slight drop in overall accuracy (~76.3%).  
| Metric             | Score   |
|--------------------|---------|
| Accuracy           | 76.3%   |
| Precision (Churn=1)| 54%     |
| Recall (Churn=1)   | 78%     |
| F1-Score (Churn=1) | 64%     |

### Iteration 3: GradientBoost (Bayesian Optimization, No OHE)
- **Change:** Adopted CatBoost for native categorical handling, no OHE. Tuned `iterations`, `learning_rate`, `depth`, `l2_leaf_reg`.  
- **Impact:** Balanced precision and recall for churners; overall accuracy ~79.9%.  
| Metric             | Score   |
|--------------------|---------|
| Accuracy           | 79.9%   |
| Precision (Churn=1)| 66%     |
| Recall (Churn=1)   | 52%     |
| F1-Score (Churn=1) | 58%     |

---

## Summary of All Models

| Model                      | Accuracy | Precision (Churn=1) | Recall (Churn=1) | F1-Score (Churn=1) |
|----------------------------|----------|---------------------|------------------|--------------------|
| Logistic Regression (Grid) | 80.8%    | 67%                 | 56%              | 61%                |
| Logistic Regression (Bayes)| 80.8%    | 67%                 | 56%              | 61%                |
| Random Forest (Bayes)      | 76.3%    | 54%                 | 78%              | 64%                |
| CatBoost (Bayes, No OHE)   | 79.9%    | 66%                 | 52%              | 58%                |

---

## Key Takeaways

- Preprocessing pipelines **standardize transformations** and prevent data leakage.  
- **Bayesian optimization** efficiently improves F1-score for minority class.  
- **Model choice impacts metrics differently:**  
  - Random Forest: best recall (78%), higher F1 (64%)  
  - Logistic Regression: highest accuracy (80.8%), moderate recall  
  - CatBoost: balances precision and overall accuracy (~79.9%)  
- **Recommendation:** For operational churn detection, prioritize **Random Forest** for its high recall and ability to detect churners effectively.