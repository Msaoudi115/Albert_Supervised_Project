import pandas as pd
import numpy as np
import os
import subprocess
import sys 


# --- 1. DYNAMIC INSTALLATION LOGIC ---

required_packages = [
    "pandas",
    "numpy",
    "scikit-learn",
    "scikit-optimize",
    "catboost" # Included catboost just in case for completeness
]

# Check if packages are installed; if not, install them using the current environment's pip
for package in required_packages:
    try:
        # Check if the package is already imported or available
        __import__(package) 
    except ImportError:
        print(f"Installing missing package: {package}...")
        try:
            subprocess.check_call([sys.executable, "-m", "pip", "install", package])
        except subprocess.CalledProcessError as e:
            print(f"Error installing {package}: {e}")
            sys.exit(1)

# -----------------------------
# IMPORTS WITH ERROR HANDLING
# -----------------------------
try:
    from pathlib import Path
    from sklearn.compose import ColumnTransformer
    from sklearn.preprocessing import StandardScaler, OneHotEncoder
    from sklearn.pipeline import Pipeline
    from sklearn.ensemble import RandomForestClassifier
    from sklearn.model_selection import train_test_split
    from sklearn.metrics import (
        accuracy_score, f1_score, precision_score, 
        recall_score, make_scorer
    )
except ImportError as e:
    missing_pkg = str(e).split()[-1]
    print(f"Error: {missing_pkg} is not installed. Please install it via pip.")
    raise

# Optional: handle skopt separately since it’s often missing
try:
    from skopt import BayesSearchCV
    from skopt.space import Integer, Categorical
except ImportError as e:
    print("Error: skopt (scikit-optimize) is not installed. Install via `pip install scikit-optimize`.")
    raise


# --- 2. REST OF THE IMPORTS (MUST BE AFTER INSTALLATION CHECK) ---

from pathlib import Path
from sklearn.compose import ColumnTransformer
from sklearn.preprocessing import StandardScaler, OneHotEncoder
from sklearn.pipeline import Pipeline
from sklearn.ensemble import RandomForestClassifier
from sklearn.model_selection import train_test_split
from sklearn.metrics import (
    accuracy_score, f1_score, precision_score, 
    recall_score, make_scorer
)
from skopt import BayesSearchCV
from skopt.space import Integer, Categorical

# -----------------------------
# PATHS
# -----------------------------
DATA_PATH = Path(r"C:\Users\anas.mossad\Desktop\Albert School\Supervised Learning\Project\WA_Fn-UseC_-Telco-Customer-Churn.csv") # Input your dataset path here
OUTPUT_PATH = Path("out")
OUTPUT_PATH.mkdir(parents=True, exist_ok=True)
SCORE_FILE = OUTPUT_PATH / "score.txt"

# -----------------------------
# LOAD DATA AND CLEANING
# -----------------------------
try:
    df = pd.read_csv(DATA_PATH)
except FileNotFoundError:
    print(f"Error: Dataset not found at {DATA_PATH}. Please ensure the file is in the correct directory.")
    sys.exit(1)

# Convert TotalCharges to numeric and fill missing (robust cleaning)
df['TotalCharges'] = pd.to_numeric(df['TotalCharges'], errors='coerce').fillna(0)

# Drop identifier
df = df.drop(columns=['customerID'])

# Features and target setup
num_features = ['tenure', 'MonthlyCharges', 'TotalCharges']
cat_features = [
    'SeniorCitizen', 'gender', 'Partner', 'Dependents', 'PhoneService', 'MultipleLines',
    'InternetService', 'OnlineSecurity', 'OnlineBackup', 'DeviceProtection',
    'TechSupport', 'StreamingTV', 'StreamingMovies', 'Contract',
    'PaperlessBilling', 'PaymentMethod'
]
target = 'Churn'

X = df.drop(columns=[target])
y = df[target].map({'Yes': 1, 'No': 0}) # Map target to 0/1

# -----------------------------
# SPLIT DATA
# -----------------------------
X_train, X_test, y_train, y_test = train_test_split(
    X, y, test_size=0.2, random_state=42, stratify=y
)

# -----------------------------
# PREPROCESSORS & PIPELINE
# -----------------------------
ohe_preprocessor = ColumnTransformer(
    transformers=[
        ('num', StandardScaler(), num_features),
        ('cat', OneHotEncoder(handle_unknown='ignore', sparse_output=False), cat_features)
    ],
    remainder='passthrough'
)

rf_pipeline = Pipeline([
    ("preprocessor", ohe_preprocessor),
    ("classifier", RandomForestClassifier(random_state=42))
])

# -----------------------------
# BAYESIAN SEARCH & OPTIMIZATION
# -----------------------------
search_spaces = {
    "classifier__n_estimators": Integer(100, 600),
    "classifier__max_depth": Integer(3, 30),
    "classifier__min_samples_split": Integer(2, 20),
    "classifier__min_samples_leaf": Integer(1, 10),
    "classifier__max_features": Categorical(["sqrt", "log2", None]),
    "classifier__class_weight": Categorical([None, "balanced"])
}

# Use F1 for the positive class (1)
f1_positive = make_scorer(f1_score, pos_label=1)

bayes_opt = BayesSearchCV(
    estimator=rf_pipeline,
    search_spaces=search_spaces,
    n_iter=25,
    cv=3,
    scoring=f1_positive,
    n_jobs=-1,
    verbose=0,
    random_state=42
)

print("Starting Bayesian Optimization (25 iterations)...")
bayes_opt.fit(X_train, y_train)

# -----------------------------
# PREDICTIONS & METRICS
# -----------------------------
y_train_pred = bayes_opt.predict(X_train)
y_test_pred = bayes_opt.predict(X_test)

metrics = {
    "Train Accuracy": accuracy_score(y_train, y_train_pred),
    "Test Accuracy": accuracy_score(y_test, y_test_pred),
    "Train Precision": precision_score(y_train, y_train_pred, pos_label=1),
    "Test Precision": precision_score(y_test, y_test_pred, pos_label=1),
    "Train Recall": recall_score(y_train, y_train_pred, pos_label=1),
    "Test Recall": recall_score(y_test, y_test_pred, pos_label=1),
    "Train F1": f1_score(y_train, y_train_pred, pos_label=1),
    "Test F1": f1_score(y_test, y_test_pred, pos_label=1)
}

# -----------------------------
# WRITE METRICS TO FILE
# -----------------------------
SCORE_FILE = OUTPUT_PATH / "score.txt"
with open(SCORE_FILE, "w") as f:
    f.write("=== Random Forest Bayesian Optimization Metrics ===\n\n")
    f.write(f"Best Hyperparameters:\n{bayes_opt.best_params_}\n\n")
    for metric, value in metrics.items():
        f.write(f"{metric}: {value:.4f}\n")

print(f"Metrics written to {SCORE_FILE}")