import pandas as pd
import numpy as np
import os
import subprocess
import sys
import importlib

# --- 1. DYNAMIC INSTALLATION LOGIC ---
required_packages = [
    ("pandas", "pandas"),
    ("numpy", "numpy"),
    ("scikit-learn", "sklearn"),
    ("scikit-optimize", "skopt"),
    ("catboost", "catboost"),
    ("mlflow", "mlflow")
]

for pip_name, import_name in required_packages:
    try:
        importlib.import_module(import_name)
    except ImportError:
        print(f"Installing missing package: {pip_name}...")
        subprocess.check_call([sys.executable, "-m", "pip", "install", pip_name])

# --- 2. IMPORTS (after installation check) ---
from pathlib import Path
from sklearn.compose import ColumnTransformer
from sklearn.preprocessing import StandardScaler, OneHotEncoder
from sklearn.pipeline import Pipeline
from sklearn.ensemble import RandomForestClassifier
from sklearn.model_selection import train_test_split, StratifiedKFold
from sklearn.metrics import accuracy_score, f1_score, precision_score, recall_score, make_scorer
from skopt import BayesSearchCV
from skopt.space import Integer, Categorical
import mlflow
import mlflow.sklearn

# -----------------------------
# PATHS
# -----------------------------
DATA_PATH = Path(r"C:\Users\anas.mossad\Desktop\Albert School\Supervised Learning\Project\WA_Fn-UseC_-Telco-Customer-Churn.csv")
OUTPUT_PATH = Path(r"C:\Users\anas.mossad\Desktop\Albert School\Supervised Learning\Project\py file\out")
OUTPUT_PATH.mkdir(parents=True, exist_ok=True)
SCORE_FILE = OUTPUT_PATH / "score.txt"

# -----------------------------
# LOAD DATA AND CLEANING
# -----------------------------
try:
    df = pd.read_csv(DATA_PATH)
except FileNotFoundError:
    print(f"Error: Dataset not found at {DATA_PATH}")
    sys.exit(1)

df['TotalCharges'] = pd.to_numeric(df['TotalCharges'], errors='coerce').fillna(0)
df = df.drop(columns=['customerID'])

num_features = ['tenure', 'MonthlyCharges', 'TotalCharges']
cat_features = [
    'SeniorCitizen', 'gender', 'Partner', 'Dependents', 'PhoneService', 'MultipleLines',
    'InternetService', 'OnlineSecurity', 'OnlineBackup', 'DeviceProtection',
    'TechSupport', 'StreamingTV', 'StreamingMovies', 'Contract',
    'PaperlessBilling', 'PaymentMethod'
]
target = 'Churn'

X = df.drop(columns=[target])
y = df[target].map({'Yes': 1, 'No': 0})

X_train, X_test, y_train, y_test = train_test_split(
    X, y, test_size=0.2, random_state=42, stratify=y
)

# -----------------------------
# PREPROCESSORS & PIPELINE
# -----------------------------
ohe_preprocessor = ColumnTransformer(
    transformers=[
        ('num', StandardScaler(), num_features),
        ('cat', OneHotEncoder(handle_unknown='ignore', sparse_output=False), cat_features)
    ],
    remainder='passthrough'
)

rf_pipeline = Pipeline([
    ("preprocessor", ohe_preprocessor),
    ("classifier", RandomForestClassifier(random_state=42))
])

# -----------------------------
# BAYESIAN SEARCH & OPTIMIZATION
# -----------------------------
search_spaces = {
    "classifier__n_estimators": Integer(100, 600),
    "classifier__max_depth": Integer(3, 30),
    "classifier__min_samples_split": Integer(2, 20),
    "classifier__min_samples_leaf": Integer(1, 10),
    "classifier__max_features": Categorical(["sqrt", "log2", None]),
    "classifier__class_weight": Categorical([None, "balanced"])
}

f1_positive = make_scorer(f1_score, pos_label=1)

skf = StratifiedKFold(n_splits=5, shuffle=True, random_state=42)
bayes_opt = BayesSearchCV(
    estimator=rf_pipeline,
    search_spaces=search_spaces,
    n_iter=25,
    cv=skf,
    scoring=f1_positive,
    n_jobs=-1,
    verbose=0,
    random_state=42
)

# -----------------------------
# MLflow Setup
# -----------------------------
mlflow.set_experiment("Telco_Churn_RF_Bayes")
with mlflow.start_run(run_name="RandomForest_BayesOpt"):

    print("Starting Bayesian Optimization (25 iterations)...")
    bayes_opt.fit(X_train, y_train)

    # Predictions
    y_train_pred = bayes_opt.predict(X_train)
    y_test_pred = bayes_opt.predict(X_test)

    # Metrics
    metrics = {
        "Train Accuracy": accuracy_score(y_train, y_train_pred),
        "Test Accuracy": accuracy_score(y_test, y_test_pred),
        "Train Precision": precision_score(y_train, y_train_pred, pos_label=1),
        "Test Precision": precision_score(y_test, y_test_pred, pos_label=1),
        "Train Recall": recall_score(y_train, y_train_pred, pos_label=1),
        "Test Recall": recall_score(y_test, y_test_pred, pos_label=1),
        "Train F1": f1_score(y_train, y_train_pred, pos_label=1),
        "Test F1": f1_score(y_test, y_test_pred, pos_label=1)
    }

    # Log hyperparameters and metrics
    mlflow.log_params(bayes_opt.best_params_)
    for metric_name, value in metrics.items():
        mlflow.log_metric(metric_name, value)

    # Log classification report
    report = f"=== Random Forest Bayesian Optimization Metrics ===\n\nBest Hyperparameters:\n{bayes_opt.best_params_}\n\n"
    for metric, value in metrics.items():
        report += f"{metric}: {value:.4f}\n"

    report_file = OUTPUT_PATH / "score.txt"
    with open(report_file, "w") as f:
        f.write(report)
    mlflow.log_artifact(str(report_file))

    # Log the trained model
    mlflow.sklearn.log_model(bayes_opt.best_estimator_, "random_forest_model")

    print(f"Metrics and model logged to MLflow. Classification report saved at {report_file}")
